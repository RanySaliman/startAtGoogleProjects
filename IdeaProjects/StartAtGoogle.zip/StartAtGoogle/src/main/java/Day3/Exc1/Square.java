package Day3.Exc1;

public class Square extends Rectangle {
    public Square(double length) {
        super(length, length);
    }
}

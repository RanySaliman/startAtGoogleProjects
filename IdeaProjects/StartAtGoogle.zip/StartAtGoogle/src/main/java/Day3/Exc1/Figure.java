package Day3.Exc1;

// Tagged class - vastly inferior to a class hierarchy! (Page 109)
interface Figure {
    public double area();

    }


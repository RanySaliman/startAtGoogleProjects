package Day3.Exc2;

public enum GENDER {
    Male,
    Female
}

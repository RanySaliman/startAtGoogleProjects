package Day3.Exc2;

public class Farmer {
}

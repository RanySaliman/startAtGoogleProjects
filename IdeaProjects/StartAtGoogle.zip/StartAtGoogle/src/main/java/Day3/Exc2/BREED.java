package Day3.Exc2;

public enum BREED {
    Dog,
    Pig,
    Sheep
}

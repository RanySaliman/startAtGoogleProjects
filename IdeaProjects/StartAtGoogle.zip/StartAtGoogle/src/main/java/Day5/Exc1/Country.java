package Day5.Exc1;

import java.util.List;

public class Country{
    public String name;
    public Integer population;
    public List<String> states;
}

package Day2;
import java.io.IOException;

import static Day2.TeamComp.teamCreation;
public class Main {



    public static void main(String[] args) throws IOException {
        teamCreation();

    }

}

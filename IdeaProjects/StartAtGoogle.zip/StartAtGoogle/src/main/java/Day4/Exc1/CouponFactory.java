package Day4.Exc1;

public class CouponFactory {
}
